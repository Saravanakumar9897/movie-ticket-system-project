<?php
/**
 * Created by PhpStorm.
 * User: banu
 * Date: 24/10/19
 * Time: 12:58 AM
 */

namespace Models;


use Connection\DB;
use PDOException;

class Theatre
{
    private $table = 't_theatres';
    private $fields = ['theatre_id','theatre_name'];

    public static function all(){
        try{
            $stmt = DB::getConnection()->prepare("SELECT * FROM t_theatres as theatres
                INNER JOIN  t_users as users
                ON theatres.r_user_id = users.user_id");
            $stmt->execute();
            $AllRows = [];
            while ($row = $stmt->fetch()){
                $AllRows[] = $row;
            }
            return $AllRows;
        } catch (PDOException $e){
            echo "Error on Theatre all function :".$e->getMessage();
        }
    }

    public static function collections(){
        try{
            $stmt = DB::getConnection()->prepare("SELECT * FROM t_theatres as theatres
                INNER JOIN t_users as users
                ON theatres.r_user_id = users.user_id
                INNER JOIN t_screens as screens
                ON theatres.theatre_id = screens.r_theatre_id
                WHERE theatres.r_user_id = users.user_id AND theatres.theatre_id = screens.r_theatre_id ");
            $stmt->execute();
            $AllRows = [];
            while ($row = $stmt->fetch()){
                $AllRows[] = $row;
            }
            return $AllRows;
        } catch (PDOException $e){
            echo "Error on Theatre all function :".$e->getMessage();
        }
    }

    public static function theatreRequest(){
        try{
            $stmt = DB::getConnection()->prepare("SELECT * FROM t_theatres ");
            $stmt->execute();
            $AllRows = [];
            while ($row = $stmt->fetch()){
                $AllRows[] = $row;
            }
            return $AllRows;
        } catch (PDOException $e){
            echo "Error on Theatre all function :".$e->getMessage();
        }
    }

    public static function insert_request($data){
        try{
            $sql = "INSERT INTO t_request_details (admin_name,email, aadhar_no,phone_NUMBER,theatre_name,no_of_screen,no_of_show,location,comments) 
                    VALUES (:admin_name,:email, :aadhar_no,:phone_NUMBER,:theatre_name,:no_of_screen, :no_of_show,:location,:comments)";
            $stmt= DB::getConnection()->prepare($sql);
            $result = $stmt->execute([
                ':r_role_id'=>$data['userRole'],
                ':name'=>$data['userName'],
                ':email'=>$data['userEmail'],
                ':password'=>$data['userMobile'],
                ':mobile_number'=>$data['userPassword'],
                ':status'=>$data['userStatus']
            ]);
            if (!$result){
                throwError('Error notified from User model at line :'.__LINE__);
            }
        } catch (PDOException $e){
            throwError("Error notified from User at line :".__LINE__."<br>".$e->getMessage());
        }
    }

    public static function select($theatre_id){
        try{
            $stmt = DB::getConnection()->prepare("SELECT * FROM t_theatres as theatres
                INNER JOIN  t_users as users
                ON theatres.r_user_id = users.user_id WHERE theatres.theatre_id=:theatre_id");
            $stmt->execute([':theatre_id'=>$theatre_id]);
            $AllRows = [];
            while ($row = $stmt->fetch()){
                $AllRows[] = $row;
            }
            return $AllRows;
        } catch (PDOException $e){
            echo "Error on Theatre all function :".$e->getMessage();
        }
    }


    public static function update($data){
        try{
            $sql = "UPDATE t_theatres
                INNER JOIN t_users
                ON t_theatres.r_user_id = t_users.user_id
                SET t_theatres.theatre_name=:theatre_name, t_users.name=:name, t_theatres.contact=:contact, t_theatres.address=:address, t_theatres.theatre_status=:status WHERE t_theatres.theatre_id=:theatre_id";
            $stmt= DB::getConnection()->prepare($sql);
            $stmt->execute([':theatre_name'=>$data['theatreName'],':name'=>$data['adminName'],':contact'=>$data['theatreContact'],':address'=>$data['address'],':status'=>$data['status'],':theatre_id'=>$data['theatreId']]);
        } catch (Throwable $e){
            dd($e->getMessage()." at line ".$e->getLine()." in ".$e->getFile());
        }
    }

    public static function delete($theatre_id){
        try{
            $sql = 'UPDATE t_theatres SET theatre_status=:status WHERE theatre_id=:theatre_id';
            $stmt = DB::getConnection()->prepare($sql);
            $stmt->execute([':status' => 0,':theatre_id'=>$theatre_id]);
        } catch (Throwable $e){
            dd($e->getMessage()." at line ".$e->getLine()." in ".$e->getFile());
        }
    }

    public static function addAdmin($data){
        try{
            $sql = "INSERT INTO t_users (name,r_role_id,email,password,mobile_number,status) VALUES (:name,:r_role_id,:email,:password,:mobile_number,:status)";
            $stmt= DB::getConnection()->prepare($sql);
            $stmt->execute([
                'r_role_id' =>2,
              ':name' => $data['adminName'],                
               ':email'=> $data['adminEmail'],
                ':password'=>$data['password'],
                ':mobile_number'=>$data['phoneNumber'],
                ':status' =>'1',           
           ]);
            
        } catch (Throwable $e){
            dd($e->getMessage()." at line ".$e->getLine()." in ".$e->getFile());
        }
    }

    public static function adminSelect($data){
        try{
            $sql = "SELECT user_id FROM t_users WHERE email=:email";
            $stmt= DB::getConnection()->prepare($sql);
            $stmt->execute([':email'=>$data['adminEmail']]);
            $AllRows = [];
            while ($row = $stmt->fetch()){
                $AllRows[] = $row;
            }
            return $AllRows[0];         
        } catch (Throwable $e){
            dd($e->getMessage()." at line ".$e->getLine()." in ".$e->getFile());
        }
    }

    public static function addTheatre($data){
        try{
            $sql = "INSERT INTO t_theatres (theatre_name,r_user_id,address,contact,theatre_status) 
            VALUES (:theatre_name,:r_user_id,:address,:contact,:theatre_status)";
            $stmt= DB::getConnection()->prepare($sql);
            $stmt->execute([':theatre_name'=>$data[0]['theatreName'],':r_user_id'=>$data[1]['user_id'] ,':address'=>$data[0]['theatreLocation'],':contact'=>$data[0]['phoneNumber'],':theatre_status'=>'1']);
        } catch (Throwable $e){
            dd($e->getMessage()." at line ".$e->getLine()." in ".$e->getFile());
        }
    }

}